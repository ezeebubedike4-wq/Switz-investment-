function signupUser(){
  const fullName=document.getElementById('fullName').value.trim();
  const email=document.getElementById('email').value.trim();
  const phone=document.getElementById('phone').value.trim();
  const password=document.getElementById('password').value.trim();
  if(!fullName||!email||!phone||!password){alert('Please fill in all details.');return;}
  const user={fullName,email,phone,password,balance:0,totalInvestments:0,totalProfit:0,transactions:[]};
  localStorage.setItem('switzUser',JSON.stringify(user));
  localStorage.setItem('switzLoggedIn','true');
  window.location.href='dashboard.html';
}
function loginUser(){
  const email=document.getElementById('loginEmail').value.trim();
  const password=document.getElementById('loginPassword').value.trim();
  const user=JSON.parse(localStorage.getItem('switzUser')||'null');
  if(!user){alert('No account found. Please sign up first.');window.location.href='signup.html';return;}
  if(user.email===email && user.password===password){localStorage.setItem('switzLoggedIn','true');window.location.href='dashboard.html';}
  else{alert('Wrong email or password.');}
}
function logoutUser(){localStorage.removeItem('switzLoggedIn');window.location.href='login.html';}
function loadDashboard(){
  if(!location.pathname.includes('dashboard.html')) return;
  const user=JSON.parse(localStorage.getItem('switzUser')||'null');
  const logged=localStorage.getItem('switzLoggedIn');
  if(!user||logged!=='true'){window.location.href='login.html';return;}
  document.getElementById('profileName').textContent=user.fullName||'New Investor';
  document.getElementById('profileEmail').textContent=user.email?'Email: '+user.email:'';
  document.getElementById('profilePhone').textContent=user.phone?'Phone: '+user.phone:'';
  document.getElementById('balance').textContent='₦'+Number(user.balance||0).toLocaleString()+'.00';
}
document.addEventListener('DOMContentLoaded',loadDashboard);